// +build NOT !windows !386

package kpathsea

func findFile_dynamic(name string, format FileFormatType, mustExist bool) string {
	return ""
}
